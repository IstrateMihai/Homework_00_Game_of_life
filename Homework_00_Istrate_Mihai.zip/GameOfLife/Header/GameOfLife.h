#pragma once

// Include all required headers in this file.

#include <iostream>

int main();

int DrawShape(std::string shape, int x, int y);
void DrawGrid();
void TestGeneration();
int GetNeighbours(int xc , int yc);
// Write method prototypes after this point.